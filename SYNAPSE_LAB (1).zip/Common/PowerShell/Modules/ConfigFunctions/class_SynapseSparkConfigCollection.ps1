class SynapseSparkConfigCollection {
    [string[]]$DefaultConfig = @()
    [hashtable]$PoolConfig = @{}
}